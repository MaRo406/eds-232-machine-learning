OK_FORMAT = True

test = {   'name': 'q1a',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> assert X_train.index[0] == np.int64(249)\n>>> assert len(X_train) == 771\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
