OK_FORMAT = True

test = {   'name': 'q10',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> assert poly_mse == np.float64(24159.54013290374)\n>>> assert poly_r2 == 0.7469797029428922\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
