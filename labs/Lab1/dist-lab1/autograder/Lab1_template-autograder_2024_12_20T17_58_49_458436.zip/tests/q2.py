OK_FORMAT = True

test = {   'name': 'q2',
    'points': 2,
    'suites': [{'cases': [{'code': ">>> assert df.columns[1] == 'albany_DO'\n", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
