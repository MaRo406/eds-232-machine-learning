OK_FORMAT = True

test = {   'name': 'q5',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> assert mse == np.float64(48731.6947400043)\n>>> assert r2 == 0.4896381383344557\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
