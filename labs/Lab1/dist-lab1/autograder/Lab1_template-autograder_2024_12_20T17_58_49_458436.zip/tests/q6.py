OK_FORMAT = True

test = {   'name': 'q6',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> assert np.round(scores[1], 3) == np.float64(-50247.532)\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
